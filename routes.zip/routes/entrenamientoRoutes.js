const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const Entrenamiento = require("../models/Entrenamiento");
const { logMovimiento } = require('../utils/logMovimiento');

// ✅ Crear
router.post("/", async (req, res) => {
  try {
    const doc = await Entrenamiento.create(req.body);
    request.body.asesorid = req.user?._id || req.body.asesorid; // para logMovimiento
    req.body.tipo = 'CREAR';
    await logMovimiento(`Entrenamiento creado: ${doc.titulo}`, req);
    res.status(201).json(doc);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// ✅ Listado general (ligero, sin populate)
router.get("/", async (req, res) => {
  try {
    const items = await Entrenamiento.find({}, {                      // proyección ligera
      titulo: 1,
      objetivo: 1,
      clienteId: 1,
      asesorid: 1,
      activo: 1,
      createdAt: 1,
      updatedAt: 1,
      semanas: { $slice: 1 }, // no enviar todo (solo para no pesar)
    })
      .sort({ updatedAt: -1, createdAt: -1 })
      .lean();

    res.json(items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ✅ Listado por cliente (para PrevisualizacionEntrenamientos)
router.get("/cliente/:clienteId", async (req, res) => {
  try {
    const { clienteId } = req.params;
    if (!mongoose.isValidObjectId(clienteId)) {
      return res.status(400).json({ error: "clienteId inválido" });
    }

    // Agregación para devolver contadores listos (semanas, días, ejercicios)
    const items = await Entrenamiento.aggregate([
      { $match: { clienteId: new mongoose.Types.ObjectId(clienteId) } },
      {
        $project: {
          titulo: 1,
          objetivo: 1,
          clienteId: 1,
          asesorid: 1,
          activo: 1,
          createdAt: 1,
          updatedAt: 1,
          semanasCount: { $size: { $ifNull: ["$semanas", []] } },
          diasCount: {
            $sum: {
              $map: {
                input: { $ifNull: ["$semanas", []] },
                as: "sem",
                in: { $size: { $ifNull: ["$$sem.dias", []] } },
              },
            },
          },
          ejerciciosCount: {
            $sum: {
              $map: {
                input: { $ifNull: ["$semanas", []] },
                as: "sem",
                in: {
                  $sum: {
                    $map: {
                      input: { $ifNull: ["$$sem.dias", []] },
                      as: "dia",
                      in: { $size: { $ifNull: ["$$dia.items", []] } },
                    },
                  },
                },
              },
            },
          },
        },
      },
      { $sort: { createdAt: -1, updatedAt: -1 } },
      { $limit: parseInt(req.query.limit ?? 100, 10) },
    ]);

    res.json(items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ✅ Detalle por ID (populate profundo SOLO aquí)
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const doc = await Entrenamiento.findById(id)
      .populate({
        path: "semanas.dias.items.ejercicio",
        select: "nombre grupo equipo nivel urlVideo instrucciones",
      })
      .lean();

    if (!doc) return res.status(404).json({ error: "Entrenamiento no encontrado" });
    res.json(doc);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ✅ Actualizar
router.put("/:id", async (req, res) => {
  try {
    const doc = await Entrenamiento.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!doc) return res.status(404).json({ error: "Entrenamiento no encontrado" });
    req.body.asesorid = req.user?._id || req.body.asesorid; // para logMovimiento
    req.body.tipo = 'EDITAR';
    await logMovimiento(`Entrenamiento actualizado: ${doc.titulo}`, req);
    res.json(doc);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// ✅ Eliminar
router.delete("/:id", async (req, res) => {
  try {
    const doc = await Entrenamiento.findByIdAndDelete(req.params.id);
    if (!doc) return res.status(404).json({ error: "Entrenamiento no encontrado" });
    req.body.asesorId = req.user?._id || req.body.asesorId; // para logMovimiento
    req.body.tipo = 'BORRAR';
    await logMovimiento(`Entrenamiento eliminado: ${doc.titulo}`, req);
    res.json({ message: "Entrenamiento eliminado correctamente" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// GET /entrenamientos/ultimo?asesor=:id
router.get('/ultimo', async (req, res) => {
  try {
    const { asesorId } = req.params;

    const ultima = await Entrenamiento.findOne({ asesorid: asesorId })
      .sort({ createdAt: -1, _id: -1 })
      .populate('clienteId', 'nombre') // para clienteNombre
      .lean();

    if (!ultima) return res.json({});

    return res.json({
      _id: ultima._id,
      createdAt: ultima.createdAt,
      updatedAt: ultima.updatedAt,
      titulo: ultima.titulo,
      clienteId: ultima.clienteId?._id || ultima.clienteId,
      clienteNombre: ultima.clienteId?.nombre || undefined,
    });
  } catch (error) {
    res.status(500).json({ error: "Error al obtener el ultimo entrenamiento" });
  }
});



module.exports = router;
