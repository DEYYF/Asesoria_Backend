const express = require("express");
const Dieta = require("../models/Dieta");
const Usuario = require("../models/Usuario");
const Receta = require("../models/Recetas");
const Ingrediente = require("../models/Ingredientes");
const mongoose = require("mongoose");
const { logMovimiento } = require('../utils/logMovimiento');

const router = express.Router();

// Crear una nueva dieta
router.post("/", async (req, res) => {
  try {
    const toOid = (v) => {
      const s = v != null ? String(v).trim() : "";
      return mongoose.Types.ObjectId.isValid(s)
        ? new mongoose.Types.ObjectId(s)
        : null;
    };
    const toNum = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : null;
    };
    const cleanStr = (v) => (typeof v === "string" ? v.trim() : "");

    // ---- Normaliza una opción
    const cleanOption = (op) => {
      if (!op || !op.tipo) return null;
      const tipo = String(op.tipo);

      if (tipo === "Receta") {
        const ref = toOid(op.refId);
        if (!ref) return null;
        return { tipo, refId: ref };
      }

      if (tipo === "Alimento") {
        const ref = toOid(op.refId);
        const gramos = toNum(op.gramos);
        if (!ref || !gramos || gramos <= 0) return null;
        return { tipo, refId: ref, gramos };
      }

      if (tipo === "Combinacion") {
        // Tu payload actual ya trae items: [{ ingrediente, gramos }]
        const items = Array.isArray(op.items)
          ? op.items
              .map((it) => {
                const ing = toOid(it?.ingrediente);
                const gr = toNum(it?.gramos);
                if (!ing || !gr || gr <= 0) return null;
                return { ingrediente: ing, gramos: gr };
              })
              .filter(Boolean)
          : [];

        if (!items.length) return null;
        return { tipo, items };
      }

      return null;
    };

    // ---- Normaliza una comida
    const cleanComida = (c, idx) => {
      const nombre = cleanStr(c?.nombre) || `Comida ${idx + 1}`;
      const opciones = Array.isArray(c?.opciones)
        ? c.opciones.map(cleanOption).filter(Boolean)
        : [];
      return { nombre, opciones };
    };

    // ---- Cuerpo
    const b = req.body || {};

    const clienteId = toOid(b.clienteId);
    const asesorid = toOid(b.asesorid);
    if (!clienteId)
      return res.status(400).json({ error: "clienteId inválido" });
    if (!asesorid) return res.status(400).json({ error: "asesorid inválido" });

    const doc = {
      clienteId,
      asesorid,
      fechaCreacion: b.fechaCreacion ? new Date(b.fechaCreacion) : undefined,
      objetivos: Array.isArray(b.objetivos)
        ? b.objetivos.map((o) => String(o)).filter(Boolean)
        : [],
      caloriasTotales: toNum(b.caloriasTotales) ?? undefined,
      macros: b.macros
        ? {
            proteinas: toNum(b.macros.proteinas) ?? 0,
            carbohidratos: toNum(b.macros.carbohidratos) ?? 0,
            grasas: toNum(b.macros.grasas) ?? 0,
          }
        : undefined,
      comidas: Array.isArray(b.comidas)
        ? b.comidas.map((c, i) => cleanComida(c, i))
        : [],
    };

    const dieta = await Dieta.create(doc);

    req.body.asesorId = String(asesorid);
    req.body.tipo = 'CREAR';


    res.json(dieta);
  } catch (err) {
    console.error("Error creando dieta:", err);
    res.status(400).json({ error: err.message || "Error al crear la dieta" });
  }
});

// Actualizar una dieta (normalizando ids, números y combinaciones)
router.put("/:id", async (req, res) => {
  try {
    const toOid = (v) => {
      const s = v != null ? String(v).trim() : "";
      return mongoose.Types.ObjectId.isValid(s)
        ? new mongoose.Types.ObjectId(s)
        : null;
    };
    const toNum = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : null;
    };
    const cleanStr = (v) => (typeof v === "string" ? v.trim() : "");

    // ---- Normaliza una opción de comida
    const cleanOption = (op) => {
      if (!op || !op.tipo) return null;
      const tipo = String(op.tipo);

      if (tipo === "Receta") {
        const ref = toOid(op.refId);
        if (!ref) return null;
        return { tipo, refId: ref };
      }

      if (tipo === "Alimento") {
        const ref = toOid(op.refId);
        const gramos = toNum(op.gramos);
        if (!ref || !gramos || gramos <= 0) return null;
        return { tipo, refId: ref, gramos };
      }

      if (tipo === "Combinacion") {
        // Acepta payload como items: [{ ingrediente, gramos }] (preferido)
        // o como alimentos: [{ ingredienteId, gramos }]
        const rawItems = Array.isArray(op.items)
          ? op.items.map((it) => ({
              ingrediente: it?.ingrediente,
              gramos: it?.gramos,
            }))
          : Array.isArray(op.alimentos)
          ? op.alimentos.map((it) => ({
              ingrediente: it?.ingredienteId,
              gramos: it?.gramos,
            }))
          : [];

        const items = rawItems
          .map((it) => {
            const ing = toOid(it?.ingrediente);
            const gr = toNum(it?.gramos);
            if (!ing || !gr || gr <= 0) return null;
            return { ingrediente: ing, gramos: gr };
          })
          .filter(Boolean);

        if (!items.length) return null;
        return { tipo, items };
      }

      return null;
    };

    // ---- Normaliza una comida completa
    const cleanComida = (c, idx) => {
      const nombre = cleanStr(c?.nombre) || `Comida ${idx + 1}`;
      const opciones = Array.isArray(c?.opciones)
        ? c.opciones.map(cleanOption).filter(Boolean)
        : [];
      return { nombre, opciones };
    };

    const b = req.body || {};
    const update = {};

    // Campos raíz (solo se actualizan si vienen en el body)
    if (b.clienteId !== undefined) {
      const v = toOid(b.clienteId);
      if (!v) return res.status(400).json({ error: "clienteId inválido" });
      update.clienteId = v;
    }

    if (b.asesorid !== undefined) {
      const v = toOid(b.asesorid);
      if (!v) return res.status(400).json({ error: "asesorid inválido" });
      update.asesorid = v;
    }

    if (b.fechaCreacion !== undefined) {
      update.fechaCreacion = b.fechaCreacion
        ? new Date(b.fechaCreacion)
        : undefined;
    }

    if (b.objetivos !== undefined) {
      update.objetivos = Array.isArray(b.objetivos)
        ? b.objetivos.map((o) => String(o)).filter(Boolean)
        : [];
    }

    if (b.caloriasTotales !== undefined) {
      const n = toNum(b.caloriasTotales);
      update.caloriasTotales = n ?? 0;
    }

    if (b.macros !== undefined) {
      update.macros = {
        proteinas: toNum(b.macros?.proteinas) ?? 0,
        carbohidratos: toNum(b.macros?.carbohidratos) ?? 0,
        grasas: toNum(b.macros?.grasas) ?? 0,
      };
    }

    if (b.comidas !== undefined) {
      update.comidas = Array.isArray(b.comidas)
        ? b.comidas.map((c, i) => cleanComida(c, i))
        : [];
    }

    const dieta = await Dieta.findByIdAndUpdate(req.params.id, update, {
      new: true,
      runValidators: true,
    });

    if (!dieta) return res.status(404).json({ error: "Dieta no encontrada" });

    req.body.asesorId = String(dieta.asesorid);
    req.body.tipo = 'EDITAR';
      await logMovimiento(`Dieta editada: ID ${dieta._id}`, dieta.asesorid);
    res.json(dieta);
  } catch (err) {
    console.error("Error actualizando dieta:", err);
    res
      .status(400)
      .json({ error: err.message || "Error al actualizar la dieta" });
  }
});

// Obtener todas las dietas de un asesor
router.get("/", async (req, res) => {
  try {
    const { asesor } = req.query;
    if (!asesor)
      return res.status(400).json({ error: "Falta el ID del asesor" });

    const asesorExiste = await Usuario.findById(asesor);
    if (!asesorExiste)
      return res.status(404).json({ error: "El asesor no existe" });

    const dietas = await Dieta.find({ asesorid: asesor });
    res.json(dietas);
  } catch (err) {
    res.status(500).json({ error: "Error al obtener dietas del asesor" });
  }
});

// Obtener dietas por cliente
router.get("/cliente/:id", async (req, res) => {
  const dietas = await Dieta.find({ clienteId: req.params.id });
  res.json(dietas);
});

// Obtener la última dieta de un cliente
router.get("/cliente/:id/ultima", async (req, res) => {
  try {
    const ultimaDieta = await Dieta.findOne({ clienteId: req.params.id }).sort({
      fechaCreacion: -1,
    });
    if (!ultimaDieta)
      return res
        .status(404)
        .json({ error: "No se encontró ninguna dieta para este cliente" });
    res.json(ultimaDieta);
  } catch (err) {
    res
      .status(500)
      .json({ error: "Error al obtener la última dieta del cliente" });
  }
});

// Obtener la última dieta creada por un asesor
router.get("/ultima", async (req, res) => {
  try {
    const { asesor } = req.query;

    const asesorExiste = await Usuario.findById(asesor);
    if (!asesorExiste)
      return res.status(404).json({ error: "El asesor no existe" });

    const ultima = await Dieta.findOne({ asesorid: asesor }).sort({
      createdAt: -1,
    });
    res.json(ultima);
  } catch (err) {
    res.status(500).json({ error: "Error al obtener la última dieta" });
  }
});

// Obtener una dieta por ID
router.get("/:id", async (req, res) => {
  try {
    const dieta = await Dieta.findById(req.params.id);
    if (!dieta) return res.status(404).json({ error: "Dieta no encontrada" });
    res.json(dieta);
  } catch (err) {
    res.status(500).json({ error: "Error al obtener la dieta" });
  }
});

// Eliminar una dieta
router.delete("/:id", async (req, res) => {
  try {
    const dieta = await Dieta.findByIdAndDelete(req.params.id);
    if (!dieta) return res.status(404).json({ error: "Dieta no encontrada" });
    req.body.asesorId = String(dieta.asesorid);
    req.body.tipo = 'BORRAR';
    await logMovimiento(`Dieta eliminada: ID ${dieta._id}`, dieta.asesorid);
    res.json({ message: "Dieta eliminada correctamente" });
  } catch (err) {
    res.status(500).json({ error: "Error al eliminar la dieta" });
  }
});

// Obtener comidas detalladas
// Obtener comidas detalladas (compatible con Receta, Alimento y Combinacion con "items")
router.get("/:id/comidas", async (req, res) => {
  try {
    const dieta = await Dieta.findById(req.params.id).lean();
    if (!dieta) return res.status(404).json({ error: "Dieta no encontrada" });

    const s = (v) => (v ? String(v) : "");
    const ZERO = { kcal: 0, proteinas: 0, carbohidratos: 0, grasas: 0 };
    const add = (a, b) => ({
      kcal: +(a.kcal + (b?.kcal || 0)).toFixed(2),
      proteinas: +(a.proteinas + (b?.proteinas || 0)).toFixed(2),
      carbohidratos: +(a.carbohidratos + (b?.carbohidratos || 0)).toFixed(2),
      grasas: +(a.grasas + (b?.grasas || 0)).toFixed(2),
    });
    const div = (a, k) => {
      const d = k > 0 ? k : 1;
      return {
        kcal: +((a.kcal || 0) / d).toFixed(2),
        proteinas: +((a.proteinas || 0) / d).toFixed(2),
        carbohidratos: +((a.carbohidratos || 0) / d).toFixed(2),
        grasas: +((a.grasas || 0) / d).toFixed(2),
      };
    };
    const scale = (per100, gramos = 0) => {
      const f = (gramos || 0) / 100;
      return {
        kcal: +((per100?.kcal || 0) * f).toFixed(2),
        proteinas: +((per100?.proteinas || 0) * f).toFixed(2),
        carbohidratos: +((per100?.carbohidratos || 0) * f).toFixed(2),
        grasas: +((per100?.grasas || 0) * f).toFixed(2),
      };
    };

    // ---- 1) Recolecta IDs de ingredientes a precargar
    const needIngIds = new Set();

    for (const c of dieta.comidas || []) {
      for (const op of c.opciones || []) {
        if (op.tipo === "Receta" && op.refId) {
          const rec = await Receta.findById(op.refId, {
            ingredientes: 1,
          }).lean();
          (rec?.ingredientes || []).forEach(
            (ing) => ing?.ingrediente && needIngIds.add(s(ing.ingrediente))
          );
        }
        if (op.tipo === "Alimento" && op.refId) {
          needIngIds.add(s(op.refId));
        }
        if (op.tipo === "Combinacion" && Array.isArray(op.items)) {
          op.items.forEach(
            (it) => it?.ingrediente && needIngIds.add(s(it.ingrediente))
          );
        }
      }
    }

    const ingredientesDocs = await Ingrediente.find(
      { _id: { $in: Array.from(needIngIds) } },
      { nombre: 1, kcal: 1, proteinas: 1, carbohidratos: 1, grasas: 1 }
    ).lean();
    const ING = new Map(ingredientesDocs.map((d) => [s(d._id), d]));

    // ---- 2) Construye respuesta
    const comidas = [];

    for (const comida of dieta.comidas || []) {
      const opciones = [];
      let sumComida = { ...ZERO };
      let nOpsConTotales = 0;

      for (const op of comida.opciones || []) {
        if (op.tipo === "Receta" && op.refId) {
          // Usa los totales precomputados de la receta
          const rec = await Receta.findById(op.refId, {
            nombre: 1,
            ingredientes: 1,
            caloriasTotales: 1,
            macrosTotales: 1,
          }).lean();

          // Lista de ingredientes (solo id, nombre, gramos)
          const ings = (rec?.ingredientes || []).map((ing) => ({
            id: s(ing.ingrediente),
            nombre: ING.get(s(ing.ingrediente))?.nombre || null,
            gramos: ing.gramos ?? null,
          }));

          const totales = {
            kcal: +(
              rec?.caloriasTotales?.toFixed?.(2) ??
              Number(rec?.caloriasTotales || 0).toFixed(2)
            ),
            proteinas: +(
              rec?.macrosTotales?.proteinas?.toFixed?.(2) ??
              Number(rec?.macrosTotales?.proteinas || 0).toFixed(2)
            ),
            carbohidratos: +(
              rec?.macrosTotales?.carbohidratos?.toFixed?.(2) ??
              Number(rec?.macrosTotales?.carbohidratos || 0).toFixed(2)
            ),
            grasas: +(
              rec?.macrosTotales?.grasas?.toFixed?.(2) ??
              Number(rec?.macrosTotales?.grasas || 0).toFixed(2)
            ),
          };

          opciones.push({
            tipo: "Receta",
            _id: s(op._id),
            refId: s(op.refId),
            nombre: rec?.nombre || null,
            ingredientes: ings,
            totales,
          });

          sumComida = add(sumComida, totales);
          nOpsConTotales++;
        } else if (op.tipo === "Alimento" && op.refId) {
          const det = ING.get(s(op.refId));
          const gramos = Number(op.gramos) || 0;
          const totales = det ? scale(det, gramos) : { ...ZERO };

          opciones.push({
            tipo: "Alimento",
            _id: s(op._id),
            refId: s(op.refId),
            nombre: det?.nombre || null,
            gramos,
            totales,
          });

          sumComida = add(sumComida, totales);
          nOpsConTotales++;
        } else if (op.tipo === "Combinacion" && Array.isArray(op.items)) {
          let t = { ...ZERO };
          const ings = op.items.map((it) => {
            const id = s(it.ingrediente);
            const det = ING.get(id);
            const gramos = Number(it.gramos) || 0;
            t = add(t, det ? scale(det, gramos) : ZERO);
            return { id, nombre: det?.nombre || null, gramos };
          });
          const nombre = ings
            .map((i) => i.nombre)
            .filter(Boolean)
            .join(" + ");

          opciones.push({
            tipo: "Combinacion",
            _id: s(op._id),
            nombre,
            ingredientes: ings,
            totales: t,
          });

          sumComida = add(sumComida, t);
          nOpsConTotales++;
        }
      }

      comidas.push({
        nombre: comida.nombre,
        opciones,
        // "totales": suma si comieras todas las opciones de esa comida (útil para "si comieras todas")
        totales: nOpsConTotales ? sumComida : null,
        // "media": promedio de kcal/macros por opción (útil para estimación)
        media: nOpsConTotales ? div(sumComida, nOpsConTotales) : null,
      });
    }

    res.json(comidas);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Error al obtener comidas" });
  }
});

module.exports = router;
