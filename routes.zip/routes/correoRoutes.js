const express = require("express");
const nodemailer = require("nodemailer");
const { logMovimiento } = require('../utils/logMovimiento');
require("dotenv").config();

const router = express.Router();

const transporter = nodemailer.createTransport({
  service: "gmail",
  secure: true,
    port: 465,
  auth: {
    user: process.env.GMAIL_USER,
    pass: "kbso vaza rfzp gvho" ,
  },
});

// POST /api/correo/enviar
router.post("/enviar", async (req, res) => {
  const { asesorId ,destinatario, asunto, mensaje} = req.body;

  if (!destinatario || !asunto || !mensaje) {
    return res.status(400).json({ error: "Faltan campos requeridos." });
  }

  try {
    const info = await transporter.sendMail({
      from: `"Asesoría Fitness" <${process.env.GMAIL_USER}>`,
      to: destinatario,
      subject: asunto,
      html: `<p>${mensaje}</p>`,
    });
    
    req.body.asesorId = asesorId; // para que logMovimiento pueda acceder al asesorId
    req.body.tipo = 'CORREO';
    await logMovimiento(req, `Correo enviado a ${destinatario} con asunto: ${asunto}`);

    res.json({ message: "Correo enviado", info });


  } catch (error) {
    console.error("Error al enviar correo:", error);
    res.status(500).json({ error: "Error al enviar el correo" });
  }
});

module.exports = router;
