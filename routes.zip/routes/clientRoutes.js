const express = require("express");
const Cliente = require("../models/Cliente");
const Dieta = require("../models/Dieta");
const Entrenamiento = require("../models/Entrenamiento");
const Cita = require("../models/Cita");
const { Types } = require("mongoose");
const router = express.Router();
const { logMovimiento } = require('../utils/logMovimiento');

// ────────────────────────────── Crear
router.post("/", async (req, res) => {
  try {
    const cliente = await Cliente.create(req.body);
    res.json(cliente);
    // Log (no bloquea)
    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "CREAR";
    await logMovimiento(req, `Cliente creado: ${cliente.nombre}`);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Listado simple
router.get("/", async (req, res) => {
  const clientes = await Cliente.find();
  res.json(clientes);
});

/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  DESTACADOS  (PONEMOS ESTA RUTA ANTES DE CUALQUIER "/:id")
 *  GET /clientes/destacados?asesorId=&limit=&cutoffDays=
 *  - Enriquecer: tieneDieta / tieneEntrenamiento
 *  - proximaCita real (primera >= hoy)
 *  - buckets: atencion / seguimiento / sinProxima
 *  - meta: pendientesHoy (citas de hoy con hora >= ahora o sin hora)
 * ─────────────────────────────────────────────────────────────────────────────
 */

router.get("/destacados", async (req, res) => {
  try {
    const { asesorId, limit = 200, cutoffDays = 3, segments } = req.query;

    const asesorMatch = asesorId
      ? { asesorId: Types.ObjectId.isValid(String(asesorId)) ? new Types.ObjectId(String(asesorId)) : String(asesorId) }
      : {};

    let segList = null;
    if (segments) segList = String(segments).split(",").map(s => s.trim()).filter(Boolean);

    const baseMatch = { ...asesorMatch, ...(segList ? { segments: { $in: segList } } : {}) };

    const clientes = await Cliente.find(baseMatch, {
      nombre: 1, email: 1, telefono: 1, Tarifa: 1, fechaFin: 1, asesorId: 1, avatarUrl: 1, segments: 1,
    })
      .sort({ updatedAt: -1, createdAt: -1, _id: -1 })
      .limit(parseInt(limit, 10))
      .lean();

    const ids = clientes.map((c) => c._id);

    const [dietas, entrenamientos] = await Promise.all([
      Dieta.find({ clienteId: { $in: ids } }, { clienteId: 1 }).lean(),
      Entrenamiento.find({ clienteId: { $in: ids } }, { clienteId: 1 }).lean(),
    ]);

    const hasDieta = new Set(dietas.map((d) => String(d.clienteId)));
    const hasEntr  = new Set(entrenamientos.map((e) => String(e.clienteId)));

    const todayISO = () => {
      const n = new Date();
      return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`;
    };
    const daysDiff = (aISO, bISO = todayISO()) => {
      if (!aISO) return null;
      return Math.floor((new Date(aISO) - new Date(bISO)) / 86400000);
    };
    const hoy = todayISO();

    const citas = await Cita.find({ clienteId: { $in: ids }, date: { $gte: hoy } })
      .sort({ date: 1, hora: 1 })
      .lean();

    const now = new Date();
    const nowHM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    const pendientesHoy = citas.filter((c) => c.date === hoy && (!c.hora || c.hora >= nowHM)).length;

    const mapCita = new Map();
    for (const c of citas) {
      const key = String(c.clienteId);
      if (!mapCita.has(key)) mapCita.set(key, c);
    }

    const cut = parseInt(cutoffDays, 10) || 3;
    const atencion = [];
    const seguimiento = [];
    const sinProxima = [];

    const items = clientes.map((c) => {
      const id = String(c._id);
      const tieneDieta = hasDieta.has(id);
      const tieneEntrenamiento = hasEntr.has(id);

      let estado = "Activo";
      const venceEn = c.fechaFin != null ? daysDiff(c.fechaFin) : null;
      if (c.fechaFin && venceEn < 0) estado = "Inactivo";
      else if (c.Tarifa && !tieneDieta && !tieneEntrenamiento) estado = "En seguimiento";

      const cita = mapCita.get(id);
      const proximaCita = cita ? { id: cita._id, title: cita.title, date: cita.date, hora: cita.hora, horaFin: cita.horaFin } : null;

      const enriched = { ...c, tieneDieta, tieneEntrenamiento, estado, venceEn, proximaCita };

      if (estado === "Inactivo" || (venceEn !== null && venceEn >= 0 && venceEn <= cut)) atencion.push(enriched);
      if (estado === "En seguimiento") seguimiento.push(enriched);
      if (!proximaCita) sinProxima.push(enriched);

      return enriched;
    });

    const smartSort = (a, b) => {
      const aNoNext = !a.proximaCita ? 0 : 1;
      const bNoNext = !b.proximaCita ? 0 : 1;
      if (aNoNext !== bNoNext) return aNoNext - bNoNext;
      const av = a.venceEn ?? 999, bv = b.venceEn ?? 999;
      if (av !== bv) return av - bv;
      return (a.nombre || "").localeCompare(b.nombre || "");
    };

    atencion.sort(smartSort);
    seguimiento.sort(smartSort);
    sinProxima.sort(smartSort);

    return res.json({
      items,
      buckets: { atencion, seguimiento, sinProxima },
      meta: {
        total: items.length,
        conProximaCita: items.filter((x) => x.proximaCita).length,
        pendientesHoy,
        cutoffDays: cut,
      },
    });
  } catch (err) {
    console.error("GET /clientes/destacados", err);
    res.status(500).json({ error: err.message || "Error generando destacados" });
  }
});


// ────────────────────────────── Historial de progreso
router.get("/:id/historial", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const cliente = await Cliente.findById(id);
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });
    res.json(cliente.historialProgreso);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Actualizar tiempo de tarifa
router.put("/:id/actualizar-tarifa", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const { Tiempo_Tarifa } = req.body;
    const meses = Tiempo_Tarifa === "1 Mes" ? 1 : Tiempo_Tarifa === "3 Meses" ? 3 : Tiempo_Tarifa === "6 Meses" ? 6 : 12;
    const fechaFin = new Date();
    fechaFin.setMonth(fechaFin.getMonth() + meses);

    const cliente = await Cliente.findByIdAndUpdate(
      id,
      { Tiempo_Tarifa, fechaInicio: new Date(), fechaFin },
      { new: true }
    );
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "EDITAR";
    await logMovimiento(req, `Tiempo de tarifa actualizado: ${cliente.nombre}`);

    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Cambiar tarifa
router.put("/:id/tarifa", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const { Tarifa, Tiempo_Tarifa, fechaFin } = req.body;
    const cliente = await Cliente.findByIdAndUpdate(
      id,
      { Tarifa, Tiempo_Tarifa, fechaFin, fechaInicio: new Date() },
      { new: true }
    );
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "EDITAR";
    await logMovimiento(req, `Tarifa cambiada: ${cliente.nombre}`);

    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Renovar
router.put("/:id/renovar", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const { Tiempo_Tarifa, fechaFin } = req.body;
    const cliente = await Cliente.findByIdAndUpdate(
      id,
      { Tiempo_Tarifa, fechaFin, fechaInicio: new Date() },
      { new: true }
    );
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "EDITAR";
    await logMovimiento(req, `Tarifa renovada: ${cliente.nombre}, hasta ${fechaFin}`);

    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Añadir historial progreso
router.put("/:id/historial", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const cliente = await Cliente.findByIdAndUpdate(
      id,
      { $push: { historialProgreso: req.body } },
      { new: true }
    );
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "PROGRESO";
    await logMovimiento(req, `Progreso añadido: ${cliente.nombre}`);

    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Get by id
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const cliente = await Cliente.findById(id);
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });
    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Update by id
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const cliente = await Cliente.findByIdAndUpdate(id, req.body, { new: true });
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "EDITAR";
    await logMovimiento(req, `Cliente actualizado: ${cliente.nombre}`);

    res.json(cliente);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ────────────────────────────── Delete by id
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!Types.ObjectId.isValid(String(id))) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const cliente = await Cliente.findByIdAndDelete(id);
    if (!cliente) return res.status(404).json({ error: "Cliente no encontrado" });

    req.body.asesorId = req.body.asesorId || cliente.asesorId;
    req.body.tipo = "BORRAR";
    await logMovimiento(req, `Cliente eliminado: ${cliente.nombre}`);

    res.json({ message: "Cliente eliminado" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
